package CodingTasks;

public class Tasks2 {
    public static void main(String[] args) {
        int[] nums = {70, 20, 85, 35, 90, 10};
        int sum=0;
        for (int i:nums) {
            sum+=i;
        }
        System.out.println("Sum of all stored elements in that array is: "+sum);
    }

    }


